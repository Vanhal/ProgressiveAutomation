package com.vanhal.progressiveautomation.entities;

import com.vanhal.progressiveautomation.ref.ToolInfo;

public class TileMinerIron extends TileMiner {
	public TileMinerIron() {
		super();
		setMiningLevel(ToolInfo.LEVEL_IRON);
	}
}
