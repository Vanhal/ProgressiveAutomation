package com.vanhal.progressiveautomation.entities;

import com.vanhal.progressiveautomation.ref.ToolInfo;

public class TileMinerStone extends TileMiner {

	public TileMinerStone() {
		super();
		setMiningLevel(ToolInfo.LEVEL_STONE);
	}
}
