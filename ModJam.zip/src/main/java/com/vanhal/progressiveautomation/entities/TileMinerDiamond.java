package com.vanhal.progressiveautomation.entities;

import com.vanhal.progressiveautomation.ref.ToolInfo;

public class TileMinerDiamond extends TileMiner {

	public TileMinerDiamond() {
		super();
		setMiningLevel(ToolInfo.LEVEL_DIAMOND);
	}
}
