package com.vanhal.progressiveautomation.core;

public class ClientProxy extends Proxy {

}
